
import java.util.ArrayList;

public class Team {
    private String name;
    private ArrayList <Student> students;
    private ArrayList <Submission> submissions;

}
