import java.util.HashMap;
/**
 * ECIJude
 *
 * @author ECI
 * @version 2020-1a
 */
public class EciJudge{
    private HashMap<String,Contest> contests;
    private HashMap<String,Problem> problems;
    private HashMap<Integer,Student> students;
    private HashMap<String,Team> teams;
    
    public EciJudge(){
    }

  
}
