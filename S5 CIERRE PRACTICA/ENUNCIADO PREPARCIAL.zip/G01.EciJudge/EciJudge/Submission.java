import java.time.LocalDateTime;

public class Submission {
    private static int nextSubmissionNumber;
    private int number;
    private String sourceCode;
    private LocalDateTime upload;
    private char status;
    private Contest contest;
    private Problem problem;

}
