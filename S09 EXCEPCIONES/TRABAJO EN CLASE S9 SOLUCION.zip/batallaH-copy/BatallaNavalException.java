
/**
 * Write a description of class BatallaNavalException here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BatallaNavalException extends Exception
{
    /**
     * Constructor for objects of class BatallaNavalException
     */
    public BatallaNavalException(String mensaje)
    {
        super(mensaje);
    }
}
