package dominio;
import java.util.*;

public class Isla{
    public static final int MAXIMO = 500;
    private static Isla isla = null;

    public static Isla demeIsla() {
        if (isla==null){
            isla=new Isla();
        }
        return isla;
    }

    private static void nuevaIsla() {
        isla=new Isla();
    }   

    public static void cambieIsla(Isla d) {
        isla=d;
    }       

    private ArrayList<EnIsla> elementos;
    private int tesoroPosX;
    private int tesoroPosY;
    private boolean encontraronTesoro;

    private Isla() {
        elementos= new ArrayList<EnIsla>();
        tesoroPosX = (int)(Math.random() * MAXIMO);
        tesoroPosY = (int)(Math.random() * MAXIMO);
        encontraronTesoro=false;
    }

    public void algunosEnIsla(){    
    }  

    public EnIsla demeEnIsla(int n){
        EnIsla h=null;
        if (1<=n && n<=elementos.size()){
            h=elementos.get(n-1);
        }    
        return h; 
    }

    
    public void adicione(EnIsla e){
        elementos.add(e);
    }

    public int numeroEnIsla(){
        return elementos.size();
    }

    public boolean enTesoro(EnIsla e){
        boolean tesoro=(tesoroPosX==e.getPosicionX() && tesoroPosY==e.getPosicionY());
        encontraronTesoro = encontraronTesoro || tesoro;
        return tesoro;
    }     
    
    public void actuen(){
    }

    public void paren(){
    }    

    public void decidan(){
    }  
}
