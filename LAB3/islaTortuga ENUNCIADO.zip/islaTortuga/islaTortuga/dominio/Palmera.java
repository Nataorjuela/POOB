package dominio;

public class Palmera {

}
