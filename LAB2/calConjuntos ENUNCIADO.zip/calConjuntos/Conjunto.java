import java.util.Arrays;
import java.util.ArrayList;

/**
 * @author ECI, 2018
 *
 */
public class Conjunto{

    
    /**
     * Constructor del conjunto
     */
  
    public Conjunto () {
    }

     /**
     * Constructor del conjunto
     */
    public Conjunto(String [] elementos){
    }
    
    /**
     * Calcula el cardinal del conjunto
     * @return
     */    
    public int cardinal() {
       return -1;
    }

    /**
     * Verifica si un elemento pertenece al conjunto
     * @param elemento, el elemento a verificar
     * @return
     */      
    public boolean pertenece(String elemento){
       return false;
    }
    
    /**
     * Compara este conjunto con otro
     * @param c el conjunto a comparar
     */
    private boolean equals (Conjunto c) {
        return false;
    }

    /** 
     * Compara si este conjunto es igual a otro (el parametro debe ser un conjunto)
     */
    @Override
    public boolean equals (Object o) {
            return this.equals ((Conjunto) o);
    }
    
    
    public boolean contenido(Conjunto c){
        return false;
    }
    
    public Conjunto union(Conjunto c){
        return null;
    }

    public Conjunto interseccion(Conjunto c){
       return null;        
    }
    
    public Conjunto diferencia(Conjunto c){
       return null;
    }    
    
    
    public Conjunto diferenciaSimetrica(Conjunto c){
       return null;
    }    
    
    public Conjunto producto(Conjunto c){
       return null;        
    }            
        
    /** 
     * Retorna una cadena que describe este conjunto con los elementos en mayusculas, entre corchetes, ordenados alfabeticamente y separados por coma
     */
    @Override
    public String toString () {
          String s = "";
          return s;
    }

}
