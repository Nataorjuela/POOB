import java.util.Stack;

/** Calculadora.java
 * Representa una calculadora de conjuntos
 * @author ESCUELA 2020-2
 */
    
public class CalConjuntos{

    private Stack<Conjunto> operandos;
    //Consultar en el API Java la clase Stack
    
    public CalConjuntos(){
    }
    
    public void adicione(String [] dConjunto){       
    }
    
    
    public void elimine(){
    }
    
    //Duplica el ultimo elemento el numero de veces indicada
    public void duplique(int times){
    }
    
    
    public int cardinal(){
        return 0;
    }
  
    //Retorna la representacion como cadena del conjunto del tope de la pila
    public String consulte(){
        return null;
    }
    
    //Operacion: U (union), I (Interseccion), - (Diferencia), _ (Diferencia simétrica), x (Producto)
    public void opere(char operacion){
    }
    
    
    public boolean ok(){
        return false;
    }
}
    



