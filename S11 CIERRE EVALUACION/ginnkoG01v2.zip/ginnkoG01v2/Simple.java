 

public class Simple extends Product {
	private Integer unitPrice;
	private int stock;
	
	public void unitsSold(int units){
	}

}
