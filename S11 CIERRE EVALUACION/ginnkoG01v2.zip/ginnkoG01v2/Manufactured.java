import java.util.ArrayList;

public class Manufactured extends Product {
	private int addedValue;
	private ArrayList<Product> products;
	
	public void unitsSold(int units) {
	}

}
