 import java.util.ArrayList;

public class Unique extends Product {
	private ArrayList<Unit> units;
	public void unitsSold(int units) {
	}

}
