 

public class Unit {

	private String reference;

	private boolean sold;

	private Integer[] unitPrice;

	public void sold() {

	}

}
