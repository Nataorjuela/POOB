 

public class WholesalerAward {
	private static int percentage;
	private int year;
	private int month;
	private int prize;
	private Wholesaler winner;
}
