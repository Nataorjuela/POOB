import java.util.HashMap;
import java.util.ArrayList;
import java.time.LocalDate;
/**
 *
 */
public class Ginnko {

    private ArrayList<Store> stores;
    private HashMap<String,Wholesaler> wholesalers;
    private HashMap<String,GlobalProduct> globalProducts;
    private HashMap<String,Category> categories;
    private HashMap<String,Zone> zones;
    private ArrayList<WholesalerAward> awards;
    /**
     * Este metodo muesta las ordenes que se pueden despachar el dia de hoy
     * @return respuesta ArrayList con las prdenes permitidas para despacho
     * @Exception NO_TODAY No hay ordenes aprobadas para el dia de hoy
     * @exception AVAILABLE_ERROR No es posible calcular por error
     */
    public ArrayList<Order>selectOrders() throws GinnkoException{
        ArrayList<Order> respuesta = new ArrayList<Order>();
        for(int i=0;i<stores.size();i++){
            ArrayList<Order> ordenes = stores.get(i).getOrders();
            for(int x=0;x<ordenes.size();x++){
                Order or = ordenes.get(i);
                if (or.darStatus() == 'A' && ordenes.get(i).darDeliveryDate().isEqual(LocalDate.now()) ){
                    respuesta.add(ordenes.get(x));
                }
            }
            
        }
        if (respuesta.size()==0){
            throw new GinnkoException(GinnkoException.NO_TODAY);
        }
        
        return respuesta;
    }
}