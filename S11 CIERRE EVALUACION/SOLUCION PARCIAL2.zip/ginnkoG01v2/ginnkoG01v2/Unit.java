 

public class Unit {

    private String reference;

    private boolean sold;

    private Integer unitPrice;

    public boolean sold() {
        return sold;
    }
    public Integer darPrecio(){
        return unitPrice;
    }
}
