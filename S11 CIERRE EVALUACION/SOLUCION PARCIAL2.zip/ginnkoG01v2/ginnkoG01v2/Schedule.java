 

public class Schedule {

	private int day;

	private String description;

}
