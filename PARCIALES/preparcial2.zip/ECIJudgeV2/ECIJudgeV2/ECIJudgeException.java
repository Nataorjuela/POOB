
/**
 * Write a description of class ECIJudgeException here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ECIJudgeException extends Exception
{
    /**
     * Constructor for objects of class ECIJudgeException
     */
    public ECIJudgeException(String mensaje)
    {  
      super(mensaje);
    }
}
