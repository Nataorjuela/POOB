
public interface Sortable {
       public abstract double weightedScore(Contest c);
}
