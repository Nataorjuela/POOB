public class Data {
	private String data;
}
