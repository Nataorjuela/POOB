import java.time.Duration;

public class Engine {
	public static boolean execute(Runable exec, Test test, Duration maxTime) {
		return false;
	}
}
