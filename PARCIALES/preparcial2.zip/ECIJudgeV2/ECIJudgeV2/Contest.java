import java.time.LocalDateTime;
import java.util.ArrayList;

public class Contest {
	private String name;
	private LocalDateTime start;
	private LocalDateTime end;
	private ArrayList<Problem> problems;
	private ArrayList<Contestant> enrolled;
	
	public ArrayList getenrolled(){
	    return enrolled;
	   }
}
