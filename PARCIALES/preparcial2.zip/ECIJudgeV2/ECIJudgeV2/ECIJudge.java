import java.util.HashMap;

public class ECIJudge {
	private HashMap<String,Student> student;
	private HashMap<String,Contest> contests;
	private HashMap<String,Problem> problems;
	private HashMap<String,Contestant> contestants;
}
