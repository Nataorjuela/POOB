public class Student extends Contestant {

	private int code;

	private String name;

	private Contestant contestant;

}
