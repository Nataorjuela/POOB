public class Runable {
	private String source;
	private String languaje;
}
