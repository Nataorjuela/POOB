import java.util.Collection;

public class Team extends Contestant {

	private Collection<Student> members;

}
