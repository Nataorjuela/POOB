import java.util.ArrayList;
/**
 * En esta clase se define un producto manufacturado.
 *
 */
public class Manufactured extends Product {
    private int addedValue;
    private ArrayList<Product> products;
    
    public void unitsSold(int units) {
    }
    /**
     * en este metodo se calcula  el número de unidades que se pueden vender del producto, se evalua el producto con menor cantidad de unidades para conocer cuantas unidades se pueden vender realmente.
     * @return int min valor de las unidades que se pueden vender
     * @exception AVAILABLE_ERROR  Si no es posible calcular por error en los datos (existencias negativas o producto mal definido).
     * @exception PRICE_PROBLEM Si el producto no se puede vender porque todavía no se conoce su precio 

     */
    public int available()throws GinnkoException{
        int min = 9999999;
        for(int i=0;i<products.size();i++){
            if (products.get(i).available() < min)
            {
                min = products.get(i).available();
            }
            
        }
        if (min<0){
            throw new GinnkoException(GinnkoException.AVAILABLE_ERROR);
        }
        if (addedValue<0){
            throw new GinnkoException(GinnkoException.PRICE_PROBLEM);
        }
        return min;
    }
}
