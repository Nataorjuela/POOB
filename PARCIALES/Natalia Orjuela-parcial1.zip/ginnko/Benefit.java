import java.time.LocalDate;
public class Benefit {
	private LocalDate date;
	private String description;
	private int discountPercentage;
}
