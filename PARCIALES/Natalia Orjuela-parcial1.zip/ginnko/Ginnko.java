import java.util.ArrayList;
import java.lang.Object;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Collections;

/**
 * Invariante: la fecha de end no puede ser uan fecha mayor a la actual.
 */
public class Ginnko {
    private ArrayList<String> products;
    private LocalDate start;
    private LocalDate end;
    /**
     * Constructor de Ginnko
     */
    public Ginnko(){
         products=new ArrayList();
    }
    /**
     * Returns the total sales of a set of products in a time range
     * @param products name of the products
     * @param start start date
     * @date end - end date
     * @return total sales
     */
    public int sales(ArrayList products,LocalDate star,LocalDate end){
        int total=0;
        for (int i=0;i<products.length;i++){
            if (subTotal(products[i])){
            total=total+subTotal(products[i]);
        }
        return total;
    }
}