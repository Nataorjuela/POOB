 import java.util.HashMap;

public class Category {
	private String name;
	private String description;
	private String image;
	private int priority;
	private HashMap<String,GlobalProduct> globalProducts;
}
