 

import java.util.ArrayList;

public class Flota {
        private Tablero tablero;
	private String nombre;
	private ArrayList<Marino> marinos;
	//Incluya el contenedor de maquinas
}
