 

import java.util.ArrayList;

public class Barco extends Maquina implements Nodriza{
    private int numero;
    private ArrayList<Marino> marinos;
    
    public boolean esDebil(){
        return false; //Falta por implementar
    }
}
