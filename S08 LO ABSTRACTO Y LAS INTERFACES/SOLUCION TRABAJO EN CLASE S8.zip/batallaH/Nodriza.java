
/**
 * Write a description of interface Nodriza here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public interface Nodriza
{
    public void destruir();
    public boolean estaDestruida();
}
