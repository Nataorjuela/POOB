
public class Ginnko {
}
