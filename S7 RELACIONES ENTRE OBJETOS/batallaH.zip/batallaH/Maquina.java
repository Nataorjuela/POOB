 

public class Maquina {
	private Ubicacion ubicacion;
}
