 

import java.util.ArrayList;

public class Barco{
	private int numero;
	private ArrayList<Marino> marinos;

}
